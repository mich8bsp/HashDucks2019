class InputState(object):
    pass