class OutputState(object):
    pass