from input_state import InputState
from output_state import OutputState
import knapsack

def run_logic(input_state):
    # type: (InputState) -> OutputState

    return OutputState()
